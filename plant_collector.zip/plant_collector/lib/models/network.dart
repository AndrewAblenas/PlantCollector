import 'package:flutter/material.dart';
import 'dart:async';
import 'package:provider/provider.dart';
import 'package:firebase_auth/firebase_auth.dart';

class UserAuthentication extends ChangeNotifier {
  //Variables
  final FirebaseAuth _firebaseAuth = FirebaseAuth.instance;
  String email;
  String password;
  FirebaseUser signedInUser;

  //REGISTER THE USER
  Future<String> userRegister() async {
    AuthResult result = await _firebaseAuth.createUserWithEmailAndPassword(
        email: email, password: password);
    FirebaseUser user = result.user;
    return user.uid;
  }

  //LOG THE USER IN
  Future<String> loginUser() async {
    print(email);
    print(password);
    AuthResult result = await _firebaseAuth.signInWithEmailAndPassword(
        email: email, password: password);
    FirebaseUser user = result.user;
    return user.uid;
  }

  //GET CURRENT USER
  Future<FirebaseUser> getCurrentUser() async {
    FirebaseUser user = await _firebaseAuth.currentUser();
    return user;
  }

  //SIGN OUT USER
  Future<void> signOutUser() async {
    return _firebaseAuth.signOut();
  }

  //SEND EMAIL FOR VERIFICATION
  Future<void> userSendEmail() async {
    FirebaseUser user = await _firebaseAuth.currentUser();
    user.sendEmailVerification();
  }

//CHECK IF EMAIL HAS BEEN VERIFIED
  Future<bool> userIsVerified() async {
    FirebaseUser user = await _firebaseAuth.currentUser();
    return user.isEmailVerified;
  }
}
