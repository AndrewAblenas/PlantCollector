import 'package:flutter/material.dart';
import 'package:plant_collector/formats/constants.dart';
import 'dart:core';

Plant plantFromMap({@required plantMap}) {
  return Plant(
    plantID: plantMap[kPlantID],
    plantVariety: plantMap[kPlantVariety],
    plantGenus: plantMap[kPlantGenus],
    plantSpecies: plantMap[kPlantSpecies],
    plantQuantity: plantMap[kPlantQuantity],
    plantNotes: plantMap[kPlantNotes],
    plantTagList: plantMap[kPlantTagList],
    plantImageList: plantMap[kPlantTagList],
  );
}

class Plant {
  //VARIABLES
  final String plantID;
  final String plantVariety;
  final String plantGenus;
  final String plantSpecies;
  final String plantQuantity;
  final String plantNotes;
  final String plantTagList;
  final String plantImageList;
  //CONSTRUCTOR
  Plant({
    @required this.plantID,
    @required this.plantVariety,
    @required this.plantGenus,
    @required this.plantSpecies,
    @required this.plantQuantity,
    @required this.plantNotes,
    @required this.plantTagList,
    @required this.plantImageList,
  });
  //METHODS
// Convert a Plant into a Map. The keys must correspond to the names of the
  // columns in the database.
  Map<String, dynamic> toMap() {
    return {
      '$kPlantID': plantID,
      '$kPlantVariety': plantVariety,
      '$kPlantGenus': plantGenus,
      '$kPlantSpecies': plantSpecies,
      '$kPlantQuantity': plantQuantity,
      '$kPlantNotes': plantNotes,
      '$kPlantTagList': plantTagList,
      '$kPlantImageList': plantImageList,
    };
  }
}

Collection collectionFromMap({@required collectionMap}) {
  return Collection(
    collectionID: collectionMap[kCollectionID],
    collectionName: collectionMap[kCollectionName],
    collectionPlantList: collectionMap[kCollectionPlantList],
    collectionCreatorID: collectionMap[kCollectionCreatorID],
  );
}

class Collection {
  //VARIABLES
  final String collectionID;
  final String collectionName;
  final String collectionPlantList;
  final String collectionCreatorID;
  //CONSTRUCTOR
  Collection({
    @required this.collectionID,
    @required this.collectionName,
    @required this.collectionPlantList,
    @required this.collectionCreatorID,
  });
  //METHODS
// Convert a Plant into a Map. The keys must correspond to the names of the
  // columns in the database.
  Map<String, dynamic> toMap() {
    return {
      '$kCollectionID': collectionID,
      '$kCollectionName': collectionName,
      '$kCollectionPlantList': collectionPlantList,
      '$kCollectionCreatorID': collectionCreatorID,
    };
  }
}
