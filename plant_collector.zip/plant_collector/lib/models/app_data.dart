import 'dart:convert';
import 'dart:core';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:path/path.dart' as p;
import 'package:plant_collector/formats/constants.dart';
import 'package:plant_collector/screens/library.dart';
import 'package:plant_collector/screens/plant.dart';
import 'package:plant_collector/widgets/buttons/button_add_plant.dart';
import 'package:plant_collector/widgets/cards/card_collection.dart';
import 'package:plant_collector/widgets/cards/card_info.dart';
import 'package:plant_collector/widgets/tiles/tile_plant.dart';
import 'package:plant_collector/widgets/buttons/button_delete.dart';
import 'package:path_provider/path_provider.dart';
import 'dart:io';
import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';
import 'package:image_picker/image_picker.dart';
import 'package:plant_collector/models/database.dart';
import 'package:plant_collector/widgets/plant_grid.dart';
import 'package:plant_collector/widgets/buttons/button_add.dart';
import 'package:plant_collector/widgets/dialogs/dialog_select.dart';
import 'package:plant_collector/widgets/tiles/tile_image.dart';
import 'package:plant_collector/widgets/buttons/button_add_image.dart';
import 'package:flutter_exif_rotation/flutter_exif_rotation.dart';
import 'package:image/image.dart' as ie;
import 'package:date_format/date_format.dart';

class AppData extends ChangeNotifier {
  //Plant Library Variables
  List<Map> _userPlantLibraryData = [];
  String newPlantVariety;
  String currentPlantID;
  //Collection Library variablesFav
  List<Map> _userCollectionLibraryData = [];
  String newDataInput;
  String selectedDialogButtonItem;
  bool hideButton;
  String forwardingCollection;
  String forwardingPlantID;
  File cameraCapture;
  List<File> imageFileList;
  String localPathSaved;
  bool loadingStatus;
  //Formatting
  Column collectionColumn = Column();
  //path and directories
  //TODO this will be set at login
  static String user = 'default';
  String pathPlants;
  String pathSettings;
  //User Store Data

//*****************CREATE DIRECTORIES*****************

  Future createDirectories({@required String user}) async {
    //get the relative path
    String path = await _localPath;

    //generate the plant folder string
    pathPlants = '$path/$kFolderUsers/$user/$kFolderPlants';
    //create directory
    await new Directory(pathPlants).create(recursive: true);

    //generate the user folder string
    pathSettings = '$path/$kFolderUsers/$user/$kFolderSettings';
    //create directory
    await new Directory(pathSettings).create(recursive: true);
  }

//*****************INITIALIZE DATABASE AND CREATE TABLES*****************

  //VARIABLE TO CREATE DATABASE AND TABLES
  final Future<Database> database = openDatabase(
    // Set the path to the database.
    join('${getDatabasesPath().toString()}/$user',
        'plant_collector_${user}_database.db'),
// When the database is first created, create a table to store plants.
    onCreate: (db, version) async {
// Run the CREATE TABLE statement on the database.
      await db.execute(
        "create table plants("
        "$kPlantID text primary key, "
        "$kPlantVariety text, "
        "$kPlantGenus text, "
        "$kPlantSpecies text, "
        "$kPlantQuantity text, "
        "$kPlantNotes text, "
        "$kPlantTagList text, "
        "$kPlantImageList text)",
      );
      await db.execute(
        "create table collections("
        "$kCollectionID text primary key, "
        "$kCollectionName text, "
        "$kCollectionPlantList text, "
        "$kCollectionCreatorID text)",
      );
    },
// Set the version. This executes the onCreate function and provides a path to perform database upgrades and downgrades.
    version: 1,
  );

  //*****************CAMERA/IMAGE/FOLDER METHODS*****************

  //METHOD FOR IMAGE ADD BUTTON
  Future<void> imageAddButtonAction() async {
    //get the image from image picker plugin
    await getImage();
    //automatically confirm, this is separate because there used to be a confirm screen
    await confirmImage();
    //regenerate the plant screen list for the open plant page
    imagesGenerateFileList(plantID: forwardingPlantID);
    //reset cameraCapture
    cameraCapture = null;
    //notify listeners
    notifyListeners();
    print('imageAddButtonAction: COMPLETE');
  }

  //METHOD TO DELETE PLANT FOLDER
  Future<void> folderPlantDelete({@required plantID}) async {
    Directory folder = Directory('$pathPlants/$plantID');
    folder.delete(recursive: true);
  }

  //METHOD TO LAUNCH IMAGE PICKER AND GET IMAGE
  Future<void> getImage() async {
    File image;
    try {
      image = await ImagePicker.pickImage(source: ImageSource.camera);
    } catch (e) {
      image = null;
    }
    //make sure the image took
    if (image != null && image.path != null) {
      //fix needed for image rotation problem on android
      // Note : iOS not implemented
      image = await FlutterExifRotation.rotateAndSaveImage(path: image.path);
    }
    cameraCapture = image;
    notifyListeners();
  }

  //METHOD TO CREATE NEW PLANT AND IMAGE FOLDERS
  Future<void> foldersPlantCreate({@required String plantID}) async {
    //create new plant directory if it doesn't exist already
    await new Directory('$pathPlants/$forwardingPlantID/$kFolderImage')
        .create(recursive: true);
  }

  //METHOD TO SAVE IMAGE FILE AND ADD PLANT REFERENCE TO FILE
  Future<void> confirmImage() async {
    //save image and create new image file from saved image
    File image = await saveImage(imageFile: cameraCapture);
    //add reference to plant list
    plantAddRemoveImage(
        plantID: forwardingPlantID, image: image, boolAddTrueRemoveFalse: true);
  }

  //METHOD TO GET LOCAL PATH
  Future<String> get _localPath async {
    final directory = await getApplicationDocumentsDirectory();
    localPathSaved = directory.path;
    return directory.path;
  }

  //METHOD TO SAVE CAMERA CAPTURE AS NEW FILE AND RETURN NEW FILE
  Future<File> saveImage({@required File imageFile}) async {
    //generate a new file name
    final String fileName = generateID(prefix: '${forwardingPlantID}_image_');
    //initialize savedImage to return
    File savedImage;
    //initialize file path
    String filePath;
    //create new plant directory if it doesn't exist already
    await new Directory('$pathPlants/$forwardingPlantID/$kFolderImage')
        .create(recursive: true)
        //check creation
        .then((Directory directory) {
      print('The new directory is ${directory.path}');
      //generate image save path
      filePath = '${directory.path}/$fileName.jpg';
      print('The new file path is $filePath)');
    });
    try {
      savedImage = await imageFile.copy(filePath);
    } catch (e) {
      print(e);
    }
    print('The savedImage path is ${savedImage.path}');
    return savedImage;
  }

  //METHOD TO GET LIST OF IMAGE FILES FOR A PLANT
  void imagesGenerateFileList({@required String plantID}) {
    //initialize list
    List<File> imageFiles = [];
    //get local path
    _localPath.then((path) {
      //load the directory
      final Directory imageDirectory =
          Directory('$pathPlants/$plantID/$kFolderImage');
      //try block in case directory is empty
      try {
        //generate a list of directory contents
        List<FileSystemEntity> imageList = imageDirectory.listSync();
        //ensure list isn't empty
        if (imageList != []) {
          //look through the list
          for (FileSystemEntity entity in imageList) {
            //check to ensure everything in the list is a file
            //really should check file type as supported image, maybe in the future
            if (entity is File) {
              //create file class from entity
              File confirmedFile = entity;
              //add to the list
              imageFiles.add(confirmedFile);
            }
          }
          imageFileList = imageFiles;
        } else {
          imageFileList = [];
        }
      } catch (e) {
        print('catch statement is: $e');
      }
    });
    print('imagesGenerateFileList: COMPLETE');
  }

  //METHOD TO DELETE FILE
  //TODO CHECK THIS METHOD
  Future<void> deleteImage({@required File image}) async {
    print(image);
    //delete image
    image.delete();
    print('deleteImage path ${image.path}');
    print('deleteImage COMPLETE');
  }

  Future deleteImageRemoveReference({@required File image}) async {
    plantAddRemoveImage(
        plantID: forwardingPlantID,
        image: image,
        boolAddTrueRemoveFalse: false);
    deleteImage(image: image);
    print('deleteImageRemoveReference COMPLETE');
  }

  //DB METHOD TO ADD AN IMAGE REFERENCE TO A PLANT
  Future<void> plantAddRemoveImage(
      {@required String plantID,
      @required File image,
      @required bool boolAddTrueRemoveFalse}) async {
    //get the db plant map for plantID
    Map plant = await plantQueryID(plantID: plantID);
    //create a local map to edit
    Map localPlant = Map.from(plant);
    //initialize plant list
    List<dynamic> plantList;
    //check if plant list has any entries
    if (localPlant[kPlantImageList] == '') {
      //if no entries to decode, just set list to blank
      plantList = [];
    } else {
      //if not blank, decode the plant string into a list
      plantList = json.decode(localPlant[kPlantImageList]);
    }
    //get file path to add
    String imageName = p.basename(image.path);
    //add/remove the new plant path to the list
    if (boolAddTrueRemoveFalse == true) {
      plantList.add(imageName);
    } else if (boolAddTrueRemoveFalse == false) {
      plantList.remove(imageName);
    }
    //encode list
    String encodedList = json.encode(plantList);
    //encode the list and replace in map
    localPlant[kPlantImageList] = encodedList;
    //create plant from map
    Plant toInsert = plantFromMap(plantMap: localPlant);
    //update plant info in DB from plant map
    plantInsertPlantClass(toInsert);
    updatePlantLocal();
    notifyListeners();
    print(
        'plantAddRemoveImage has completed, using bool $boolAddTrueRemoveFalse where Add = true');
  }

  //METHOD TO CREATE THUMBNAIL
  Future<void> imageCreateThumbnail({@required File image}) async {
    //first delete the existing file which has a different name
    imageDeleteThumbnail(plantID: forwardingPlantID);
    //create directory
    await new Directory('$pathPlants/$forwardingPlantID/$kFolderThumbnail')
        .create(recursive: true)
        //check creation
        .then((Directory directory) {
      //generate image save path
      String thumbnailSavePath =
          '${directory.path}/thumbnail-${DateTime.now().millisecondsSinceEpoch.toString()}.png';
      //file to extended image type
      ie.Image extendedImage = ie.decodeImage(image.readAsBytesSync());
      //crop and resize
      ie.Image thumbnail = ie.copyResizeCropSquare(extendedImage, 250);
      //save the thumbnail as a PNG.
      File thumbnailFile = File(thumbnailSavePath);
      //write new file
      thumbnailFile..writeAsBytesSync(ie.encodePng(thumbnail));
    });
    //Deleting doesn't help maybe need to rename?
    notifyListeners();
    print('imageCreateThumbnail: COMPLETE');
  }

  Future<void> imageDeleteThumbnail({@required plantID}) async {
    //create directory
    Directory thumbnailDirectory =
        Directory('$pathPlants/$plantID/$kFolderThumbnail');
    //check if it exists yet
    if (thumbnailDirectory.existsSync()) {
      //if exists delete directory and contents
      thumbnailDirectory.delete(recursive: true);
    } else {
      //do nothing
    }
  }

  //METHOD TO GET THUMBNAIL
  //TODO I think I need a consumer around this image file?  Not sure...
  File imageGetThumbnail({@required String plantID}) {
    //initialize file
    File thumbnail;
    //string for the file to get
    Directory plantDirectory = Directory('$pathPlants/$plantID/');
    //check if exists
    if (plantDirectory.existsSync()) {
      //create a list of file system entities
      List<FileSystemEntity> folderList =
          plantDirectory.listSync(recursive: true);
      //look through list
      for (FileSystemEntity entity in folderList) {
        //check for thumbnail image
        if (entity.path.contains('.png')) {
          //then get the file
          thumbnail = File(entity.path);
          //otherwise
        } else {
          //set to null, get alternative in widget
          thumbnail = null;
        }
      }
      //otherwise
    } else {
      //set to null, get alternative in widget
      thumbnail = null;
    }
    //create file and return
    return thumbnail;
  }

  //METHOD TO GET IMAGE COUNT
  String imageCount() {
    //initialize image count
    String images;
    //create a directory object for the plant folder
    Directory plantsFolder = Directory('$pathPlants');
    //check that the list contains a plant directory
    if (plantsFolder.existsSync()) {
      //initialize image count int
      int intImages = 0;
      //create a list of items in the plant folder including sub folders
      List<FileSystemEntity> directoryList =
          plantsFolder.listSync(recursive: true);
      //then look through each entry
      for (FileSystemEntity entity in directoryList) {
        //to see if it's an image as designated by file name
        if (entity.path.contains('_image_')) {
          //then add to the file count
          intImages++;
          //otherwise
        } else {
          //do nothing
        }
      }
      //convert to string
      images = intImages.toString();
    } else {
      //do nothing
    }
    //return
    print('imageCount: COMPLETE');
    return images;
  }

  //*****************LOCAL VARIABLE METHODS*****************

  //UPDATE LOCAL COLLECTION LIBRARY TO MATCH DB COLLECTION
  void updateCollectionLocal() {
    collectionsGetAll().then((collections) {
      if (collections != null) {
        _userCollectionLibraryData = collections;
      }
    });
  }

  //UPDATE LOCAL PLANT LIBRARY TO MATCH DB COLLECTION
  void updatePlantLocal() {
    plantsGetAll().then((plants) {
      if (plants != null) {
        _userPlantLibraryData = plants;
      }
    });
  }

  //INIT STATE
  Future<void> initLibraryState() async {
    //get collections
    updateCollectionLocal();
    //get plants
    updatePlantLocal();
    //create user directories if they don't exist
    createDirectories(user: user);
    //this seems to be needed to ensure things load before library generates
    await Future.delayed(Duration(seconds: 1));
  }

  //*****************COLLECTION METHODS*****************

  //DB METHOD TO GET NUMBER OF COLLECTIONS IN COLLECTION DATABASE
  String collectionCount() {
    String collections;
    database.then((db) {
      // Query the table for all Plants
      db.query('collections').then((maps) {
        if (maps.length != null) {
          collections = maps.length.toString();
        } else {
          collections = '0';
        }
      });
    });
    return collections;
  }

  //COLLECTION COUNT LOCAL
  String collectionCountLocal() {
    return _userCollectionLibraryData.length.toString();
  }

  //DB METHOD TO CREATE NEW COLLECTION AND INSERT
  void collectionNew() {
    String generateCollectionID = generateID(prefix: 'collection_');
    String newCollectionName = newDataInput.toUpperCase();
    final collection = Collection(
      collectionID: generateCollectionID,
      collectionName: newCollectionName,
      collectionPlantList: '[]',
      collectionCreatorID: user,
    );
    collectionInsertCollectionClass(collection);
    updateCollectionLocal();
  }

  //DB METHOD TO INSERT NEW COLLECTION INTO COLLECTION
  Future<void> collectionInsertCollectionClass(Collection collection) async {
    // Get a reference to the database.
//    print(collection.collectionPlantList);
    final Database db = await database;
    // `conflictAlgorithm` to use in case the same collection is inserted twice.
    // In this case, replace any previous data.
    await db.insert(
      'collections',
      collection.toMap(),
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
    updateCollectionLocal();
    notifyListeners();
    print('collectionInsertCollectionClass has completed.');
    //TEST GOOD - Collections are saving to DB
  }

  //DB METHOD TO INSERT COLLECTION MAP INTO COLLECTION
//  Future<void> collectionInsertMap(Map collection) async {
//    // Get a reference to the database.
//    final Database db = await database;
//    // `conflictAlgorithm` to use in case the same collection is inserted twice.
//    // In this case, replace any previous data.
//    await db.insert(
//      'collections',
//      collection,
//      conflictAlgorithm: ConflictAlgorithm.replace,
//    );
//  }

  //DB METHOD TO RETURN COLLECTION MAP FUTURE
  Future<Map> collectionQueryID({@required String collectionID}) async {
    // Get a reference to the database.
    final db = await database;
    final List<Map<String, dynamic>> matchingList = await db.query(
      'collections',
      // Ensure that the Plant has a matching id.
      where: "$kCollectionID = ?",
      whereArgs: [collectionID],
    );
    return matchingList[0];
  }

  //DB METHOD TO RENAME A COLLECTION
  Future<void> collectionRename({@required collectionID}) async {
    Map collection = await collectionQueryID(collectionID: collectionID);
    Map localCollection = Map.from(collection);
    localCollection[kCollectionName] = newDataInput;
    Collection localCollectionClass =
        collectionFromMap(collectionMap: localCollection);
    collectionInsertCollectionClass(localCollectionClass);
  }

  //DB METHOD TO DELETE A COLLECTION
  Future<void> collectionDelete({@required String collectionID}) async {
    final db = await database;
    Map collection = await collectionQueryID(collectionID: collectionID);
    List<dynamic> plantList = json.decode(collection[kCollectionPlantList]);
    if (plantList.isEmpty) {
      // Remove the Collection from the Database.
      await db.delete(
        'collections',
        // Use a `where` clause to delete a specific collection.
        where: "$kCollectionID = ?",
        // Pass the Collection's id as a whereArg to prevent SQL injection.
        whereArgs: [collectionID],
      );
      updateCollectionLocal();
      notifyListeners();
    }
    print('collectionDelete: COMPLETE');
  }

  //DB METHOD TO DELETE ALL COLLECTIONS
  Future<void> collectionDeleteAll() async {
    final db = await database;
    // Remove the Collection from the Database.
    await db.delete(
      'collections',
    );
    updateCollectionLocal();
  }

  //*****************COLLECTION PLANT ASSOCIATION METHODS*****************

  //DB METHOD TO ADD A PLANT TO A COLLECTION
  Future<void> collectionAddPlant(
      {@required requestedCollectionID, @required requestedPlantID}) async {
    Map collection =
        await collectionQueryID(collectionID: requestedCollectionID);
    Map localCollection = Map.from(collection);
    List<dynamic> plantList =
        json.decode(localCollection[kCollectionPlantList]);
    plantList.add(requestedPlantID);
    String id = localCollection[kCollectionID];
    String name = localCollection[kCollectionName];
    String list = json.encode(plantList);
    Collection toInsert = Collection(
      collectionID: id,
      collectionName: name,
      collectionPlantList: list,
      //TODO change this to current user ID after login set up
      collectionCreatorID: '',
    );
    collectionInsertCollectionClass(toInsert);
  }

  //DB METHOD TO REMOVE PLANT FROM A COLLECTION
  Future<void> collectionRemovePlant(
      {@required requestedCollectionID, @required requestedPlantID}) async {
    //get collection map from DB
    Map collection =
        await collectionQueryID(collectionID: requestedCollectionID);
    //create local map that can be modified
    Map localCollection = Map.from(collection);
    //pull out plant list
    List<dynamic> plantList =
        json.decode(localCollection[kCollectionPlantList]);
    //edit plant list
    plantList.remove(requestedPlantID);
    //encode and add back to map
    localCollection[kCollectionPlantList] = json.encode(plantList);
    //insert updates into the DB
    collectionInsertCollectionClass(
        collectionFromMap(collectionMap: localCollection));
  }

  //DB METHOD TO MOVE A PLANT TO A DIFFERENT COLLECTION
  Future<void> collectionMovePlant(
      {@required currentCollectionID, @required plantID}) async {
    String newCollectionID = selectedDialogButtonItem;
    collectionAddPlant(
        requestedCollectionID: newCollectionID, requestedPlantID: plantID);
    collectionRemovePlant(
        requestedCollectionID: currentCollectionID, requestedPlantID: plantID);
  }

  //DB METHOD TO GENERATE THE LIST OF PLANTS ASSOCIATED WITH A COLLECTION
  Future<String> collectionPlantList({@required String collectionID}) async {
    String plantList;
    Map collection = await collectionQueryID(collectionID: collectionID);
    if (collection != null && collection[kCollectionPlantList] != '') {
      plantList = collection[kCollectionPlantList];
    }
    return plantList;
  }

  //*****************PLANT METHODS*****************

  //DB METHOD TO DELETE ALL PLANTS
  Future<void> plantDeleteAll() async {
    final db = await database;
    // Remove the Collection from the Database.
    await db.delete(
      'plants',
    );
    updatePlantLocal();
  }

  //DB METHOD TO CREATE NEW PLANT
  void plantNew({@required collectionID}) {
    String newPlantID = generateID(prefix: 'plant_');
    String newPlantCollection = collectionID;
    final plant = Plant(
        plantID: newPlantID,
        plantVariety: newDataInput,
        plantGenus: '',
        plantSpecies: '',
        plantQuantity: '',
        plantNotes: '',
        plantTagList: '',
        plantImageList: '');
    plantInsertPlantClass(plant);
    collectionAddPlant(
        requestedCollectionID: newPlantCollection,
        requestedPlantID: newPlantID);
    foldersPlantCreate(plantID: newPlantID);
  }

  //DB METHOD TO INSERT PLANT INTO DATABASE
  Future<void> plantInsertPlantClass(Plant plant) async {
    // Get a reference to the database.
    final Database db = await database;
    // `conflictAlgorithm` to use in case the same plant is inserted twice.
    // In this case, replace any previous data.
    await db.insert(
      'plants',
      plant.toMap(),
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
    updatePlantLocal();
    notifyListeners();
  }

  //METHOD TO GENERATE A NEW ID
  String generateID({@required String prefix}) {
    String newPlantID =
        prefix + DateTime.now().millisecondsSinceEpoch.toString();
    return newPlantID;
  }

  //DB METHOD TO RETRIEVE ALL THE PLANTS IN THE DATABASE AS LIST
  Future<List<Map>> plantsGetAll() async {
    // Get a reference to the database.
    final Database db = await database;
    // Query the table for all Plants
    final List<Map<String, dynamic>> maps = await db.query('plants');
    return maps;
  }

  //DB METHOD TO RETRIEVE ALL THE COLLECTIONS IN THE DATABASE AS FUTURE LIST
  Future<List<Map>> collectionsGetAll() async {
    final Database db = await database;
    //make sure to return sorted list ASC or DESC so card placement doesn't change
    final List<Map<String, dynamic>> maps =
        await db.query('collections', orderBy: 'collectionID ASC');
    return maps;
  }

  //DB METHOD TO RETURN PLANT MAP FUTURE
  Future<Map> plantQueryID({@required String plantID}) async {
    // Get a reference to the database.
    final db = await database;
    final List<Map<String, dynamic>> matchingList = await db.query(
      'plants',
      // Ensure that the Plant has a matching id.
      where: "$kPlantID = ?",
      whereArgs: [plantID],
    );
    return matchingList[0];
  }

  //DB METHOD TO SHOW NEW PLANT KEY (DOESN'T DISPLAY WHEN READS AS NULL)
  Future<void> plantShowKey({@required plantID, @required key}) async {
    newDataInput = '  ';
    await plantUpdateValue(plantID: plantID, plantKey: key);
    newDataInput = null;
  }

  //DB METHOD TO UPDATE PARTICULAR PLANT DATA
  Future<void> plantUpdateValue({@required plantID, @required plantKey}) async {
    // Get a reference to the database.
    Map plantMap = await plantQueryID(plantID: plantID);
    //create a local map that can be edited
    Map localMap = Map.from(plantMap);
    //edit map
    localMap[plantKey] = newDataInput;
    //create plant
    Plant updatedPlant = plantFromMap(plantMap: localMap);
    //insert plant
    await plantInsertPlantClass(updatedPlant);
    //in using this function to hide plant info cards if you delete too quick, screen won't update
    newDataInput = null;
    print('plantUpdateValue Completed');
  }

  //DB METHOD TO GET SPECIFIC PLANT DATA
  Future<String> plantGetValue(
      {@required String requestedPlantID,
      @required String requestedPlantData}) async {
    Map plantMap = await plantQueryID(plantID: requestedPlantID);
    String value = plantMap[requestedPlantData];
    return value;
  }

  //METHOD TO GET SPECIFIC PLANT DATA FROM LOCAL VARIABLE
  String plantGetValueLocal(
      {@required String requestedPlantID,
      @required String requestedPlantData}) {
    String requestedInfo;
    for (Map plant in _userPlantLibraryData) {
      if (plant.containsValue(requestedPlantID)) {
        if (plant.containsKey(requestedPlantData)) {
          requestedInfo = plant[requestedPlantData];
        } else {
          requestedInfo = '';
        }
      }
    }
    return requestedInfo;
  }

  //DB METHOD TO DELETE A PLANT
  Future<void> plantDelete({@required String plantID}) async {
    // Get a reference to the database.
    final db = await database;
    // Remove the Plant from the Database.
    await db.delete(
      'plants',
      // Use a `where` clause to delete a specific plant.
      where: "$kPlantID = ?",
      // Pass the Plant's id as a whereArg to prevent SQL injection.
      whereArgs: [plantID],
    );
    await folderPlantDelete(plantID: plantID);
    updatePlantLocal();
  }

  //TODO CHECK THIS METHOD?  ALMOST LIKE PLANT DELETE RUNS TWICE?!
  //DB METHOD TO REMOVE PLANT FROM THE COLLECTION AND DELETE
  void plantRemoveReferenceDelete({@required plantID}) async {
    await collectionRemovePlant(
        requestedCollectionID: forwardingCollection, requestedPlantID: plantID);
    await plantDelete(plantID: plantID);
    updateCollectionLocal();
    updatePlantLocal();
    notifyListeners();
  }

  //METHOD TO LOOK UP PLANT KEY DESCRIPTION GIVEN KEY
  String plantKeyDescription({@required key}) {
    String keyDescription = kPlantKeyDescriptorsMap[key];
    return keyDescription;
  }

  //DB METHOD TO DETERMINE IF ALL PLANT INFO HAS BEEN ADDED
  Future<bool> plantInfoComplete({@required String plantID}) async {
    bool status;
    Map plant = await plantQueryID(plantID: plantID);

    if (plant.keys.toList().length ==
        kPlantKeyDescriptorsMap.keys.toList().length) {
      status = true;
    } else {
      status = false;
    }
    return status;
  }

  //DB METHOD TO GET NUMBER OF PLANTS IN PLANT DATABASE
  String plantCount() {
    String plants;
    database.then((db) {
      // Query the table for all Plants
      db.query('plants').then((maps) {
        if (maps.length != null) {
          plants = maps.length.toString();
        } else {
          plants = '0';
        }
      });
    });
    print(plants);
    return plants;
  }

  //DB METHOD TO GET NUMBER OF PLANTS IN LOCAL VARIABLE
  String plantCountLocal() {
    return _userPlantLibraryData.length.toString();
  }

  //*****************BUILDER FUNCTIONS AND RELATED*****************

  //GENERATE PLANT TILE WIDGET LIST
  List<Widget> createPlantTileList({Map collection}) {
    String collectionID = collection[kCollectionID];
    List plantList = json.decode(collection[kCollectionPlantList]);
    List<Widget> plantTileList = [];
    //Get plant list
    if (plantList != null) {
      if (plantList.length == 0) {
        plantTileList.add(ButtonDelete(collectionID: collectionID));
      } else {
        for (String plantID in plantList) {
          //Call function to get plant data
          String plantName = plantGetValueLocal(
              requestedPlantID: plantID, requestedPlantData: kPlantVariety);
          plantTileList.add(
            TilePlant(
              tileLabel: '$plantName',
              tilePlantID: '$plantID',
              collectionID: collectionID,
            ),
          );
        }
      }
    }
    plantTileList.add(ButtonAddPlant(collectionID: collectionID));
    return plantTileList;
  }

  //GENERATE IMAGE TILE WIDGET LIST
  List<Widget> createImageTileList({String plantID}) {
    //initialize the widget list
    List<Widget> imageTileList = [];
    //access imageFileList saved on plant tile press
    List<File> imageFiles = imageFileList;
    //check to make sure file is not null
    if (imageFiles != null) {
      //look through list
      for (File file in imageFiles) {
        //split off the extension
        List splitExtension = p.basename(file.path).split('.');
        //split the file name at underscores to get seconds since epoch
        List splitList = splitExtension[0].toString().split('_');
        //the format is collection_****_plant_TIMEDATE so take index 3 for ms since epoch
        int sinceEpoch = int.parse(splitList[3]);
        //turn into a date
        DateTime imageDate = DateTime.fromMillisecondsSinceEpoch(sinceEpoch);
        //convert into a more readable string
        String date = formatDate(imageDate, [MM, ' ', d, ', ', yyyy]);
        //create image tiles
        imageTileList.add(
          TileImage(image: file, imageDate: date),
        );
      }
    } else {}
    //add an image add button to the list
    imageTileList.add(ButtonAddImage(plantID: plantID));
    print('createImageTileList: COMPLETE');
    return imageTileList;
  }

  //GENERATE COLLECTION WIDGETS
  Column displayCollections() {
    //initialize widget list
    List<CardCollection> collectionList = [];
    //initialize column
    Column collectionColumn;
    //ensure memory library not empty
    if (_userCollectionLibraryData != null) {
      //look through the sorted map list
      for (Map collection in _userCollectionLibraryData) {
        List list = collection.values.toList();
        //get collectionName
        String collectionTitle = list[1];
        //get collectionID
        String collectionID = list[0];
        //get plant list
        List<dynamic> plantList = json.decode(collection[kCollectionPlantList]);
        //initialize number of plants
        String collectionPlantTotal = 'No';
        if (plantList.isNotEmpty) {
          collectionPlantTotal = plantList.length.toString();
        }
        //WORKS
        Widget collectionWidgets =
            PlantGrid(createPlantTileList(collection: collection));
        collectionList.add(
          CardCollection(
            collectionName: '$collectionTitle',
            collectionID: collectionID,
            collectionPlantTotal: collectionPlantTotal,
            collectionChild: collectionWidgets,
          ),
        );
      }
      collectionColumn = Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: collectionList,
      );
    } else if (_userCollectionLibraryData.length == 0) {
      collectionColumn = Column();
    }
    return collectionColumn;
  }

  //CREATE COLLECTION BUTTONS
  Column createCollectionListButtons(
      {@required plantID, @required oldCollectionID}) {
    List<Widget> widgetList = [];
    for (Map collection in _userCollectionLibraryData) {
      if (!collection.containsValue(oldCollectionID)) {
        widgetList.add(
          ButtonDialogSelect(
            buttonKey: collection[kCollectionID],
            buttonText: collection[kCollectionName],
            pushPage: LibraryScreen(),
            onPress: () async {
              selectedDialogButtonItem = collection[kCollectionID];
              await collectionMovePlant(
                  plantID: plantID, currentCollectionID: oldCollectionID);
              notifyListeners();
              selectedDialogButtonItem = null;
            },
          ),
        );
      }
    }
    //clear the input because if the same value is selected twice things don't update
    selectedDialogButtonItem = null;
    return Column(
      children: widgetList,
    );
  }

  //CREATE PLANT LIST BUTTONS
  Column createDialogWidgetList({@required plantID, @required context}) {
    //create a blank list to populate with widgets
    List<Widget> listItems = [];
    //create list of all plant keys in the constant map
    List list = kPlantKeyDescriptorsMap.keys.toList();
    //create list of plant keys not displayed in plant screen
    List<String> plantKeysNotDisplayed = [];
    for (Map plant in _userPlantLibraryData) {
      if (plant.containsValue(plantID)) {
        for (String key in list) {
          if (plant[key] == '') {
            plantKeysNotDisplayed.add(key);
          }
        }
        plantKeysNotDisplayed.remove(kPlantImageList);
        for (String key in plantKeysNotDisplayed) {
          listItems.add(
            ButtonDialogSelect(
              buttonKey: key,
              buttonText: plantKeyDescription(key: key),
              pushPage: PlantScreen(
                plantID: plantID,
              ),
              onPress: () {
                plantShowKey(plantID: plantID, key: key);
                notifyListeners();
              },
            ),
          );
        }
      }
    }
    return Column(
      children: listItems,
    );
  }

  //GENERATE INFO CARD WIDGETS
  //TODO issue here where they don't regen?
  Column displayInfoCards({plantID, context}) {
    //create blank list to hold info card widgets
    List<Widget> infoCardList = [];
    //look through each map in the local db copy
    for (Map plant in _userPlantLibraryData) {
      //to see if the map contains the requested plant ID
      if (plant.containsValue(plantID)) {
        //create a list of all key values possible
        List<String> keyList = kPlantKeyDescriptorsMap.keys.toList();
        //remove the plantID and plantImageList (this will be displayed elsewhere)
        keyList.remove(kPlantID);
        keyList.remove(kPlantImageList);
        //for  all these strings in the list
        for (String key in keyList) {
          //check to see that they aren't set to default value (hidden)
          if (plant[key] != '') {
            //if not default then create a widget and add to the list
            String displayLabel = plantKeyDescription(key: key);
            String displayText = plant[key];
            infoCardList.add(
              CardInfo(
                plantID: plantID,
                cardKey: key.toString(),
                displayLabel: displayLabel,
                displayText: displayText,
              ),
            );
          }
        }
      }
    }
    if (infoCardList.length < 6) {
      infoCardList.add(
        ButtonAdd(
          buttonText: 'Add Information',
          dialog: DialogSelect(
            title: 'Add Information',
            text: 'Please select the type of new information below:',
            plantID: plantID,
            listBuildColumn:
                createDialogWidgetList(plantID: plantID, context: context),
          ),
        ),
      );
    }
    print('displayInfoCards: COMPLETE');
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      mainAxisSize: MainAxisSize.min,
      children: infoCardList,
    );
  }

  //*****************APP DATA SECTION END*****************
}
