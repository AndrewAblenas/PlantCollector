//import list
import 'package:flutter/material.dart';
import 'package:plant_collector/models/network.dart';
import 'package:plant_collector/screens/library.dart';
import 'package:plant_collector/screens/collection.dart';
import 'package:plant_collector/screens/login.dart';
import 'package:plant_collector/screens/register.dart';
import 'package:plant_collector/screens/plant.dart';
import 'package:plant_collector/screens/settings.dart';
import 'package:plant_collector/screens/image.dart';
import 'package:provider/provider.dart';
import 'models/app_data.dart';

//main function call to launch app
void main() => runApp(PlantCollector());

//root function
class PlantCollector extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider(
      builder: (context) => AppData(),
      child: ChangeNotifierProvider(
        builder: (context) => UserAuthentication(),
        child: MaterialApp(
          initialRoute: 'login',
          routes: {
            'library': (context) => LibraryScreen(),
            'collection': (context) => CollectionScreen(),
            'login': (context) => LoginScreen(),
            'register': (context) => RegisterScreen(),
            'plant': (context) => PlantScreen(),
//          'camera': (context) => CameraScreen(),
            'image': (context) => ImageScreen(),
            'settings': (context) => SettingsScreen(),
          },
        ),
      ),
    );
  }
}
