import 'package:flutter/material.dart';

//Application Constants

//Directories

//images folder name
final String kFolderUsers = 'users';
final String kFolderPlants = 'plants';
final String kFolderImage = 'images';
final String kFolderThumbnail = 'thumbnail';
final String kFolderDB = 'db';
final String kFolderSettings = 'settings';
//db stored in local path

//Collection
final String kCollectionID = 'collectionID';
final String kCollectionName = 'collectionName';
final String kCollectionPlantList = 'collectionPlantList';
final String kCollectionCreatorID = 'collectionCreatorID';

//Plant Keys
final String kPlantID = 'plantID';
final String kPlantVariety = 'plantVariety';
final String kPlantGenus = 'plantGenus';
final String kPlantSpecies = 'plantSpecies';
final String kPlantQuantity = 'plantQuantity';
final String kPlantNotes = 'plantNotes';
final String kPlantTagList = 'plantTagList';
final String kPlantImageList = 'plantImageList';

//Plant Key Descriptors
final String kPlantIDDescription = 'Plant Library ID';
final String kPlantVarietyDescription = 'Cultivar/Variety';
final String kPlantGenusDescription = 'Genus';
final String kPlantSpeciesDescription = 'Species';
final String kPlantQuantityDescription = 'Quantity';
final String kPlantNotesDescription = 'Notes';
final String kPlantTagListDescription = 'Tags';
final String kPlantImageListDescription = 'Image Files';

//Plant Key Descriptors Map
Map<String, String> kPlantKeyDescriptorsMap = {
  kPlantID: kPlantIDDescription,
  kPlantVariety: kPlantVarietyDescription,
  kPlantGenus: kPlantGenusDescription,
  kPlantSpecies: kPlantSpeciesDescription,
  kPlantQuantity: kPlantQuantityDescription,
  kPlantNotes: kPlantNotesDescription,
  kPlantTagList: kPlantTagListDescription,
  kPlantImageList: kPlantImageListDescription,
};

//Application Colours

//Greens
final Color kGreenDark = Color(0xFF207561);
final Color kGreenMedium = Color(0xFF589167);
final Color kGreenLight = Color(0xFFA0cc78);
//Box Shadow
final Color kShadowColor = Color(0x66000000);
final List<Shadow> kShadowText = [Shadow(color: kShadowColor, blurRadius: 5.0)];
final List<BoxShadow> kShadowBox = [
  BoxShadow(
    color: kShadowColor,
    blurRadius: 5.0,
    offset: Offset(
      0.0,
      3.0,
    ),
  ),
];
