import 'package:flutter/material.dart';
import 'package:plant_collector/formats/constants.dart';
import 'package:plant_collector/models/app_data.dart';
import 'package:plant_collector/widgets/carousel.dart';
import 'package:plant_collector/widgets/dialogs/dialog_confirm.dart';
import 'package:plant_collector/widgets/stateful_wrapper.dart';
import 'package:provider/provider.dart';

class PlantScreen extends StatelessWidget {
  final String plantID;
  PlantScreen({this.plantID});
  @override
  Widget build(BuildContext context) {
    return StatefulWrapper(
      onInit: () async {
        Provider.of<AppData>(context).loadingStatus = true;
        await Provider.of<AppData>(context).initLibraryState();
        Provider.of<AppData>(context).loadingStatus = false;
      },
      child: SafeArea(
        child: Scaffold(
          backgroundColor: kGreenLight,
          appBar: AppBar(
            backgroundColor: kGreenDark,
            centerTitle: true,
            elevation: 20.0,
            title: Text(
              'PLANT COLLECTOR',
              style: TextStyle(color: kGreenLight, fontSize: 25.0),
            ),
            leading: FlatButton(
              child: Icon(
                Icons.list,
                color: kGreenLight,
                size: 40.0,
              ),
              onPressed: () {
                Navigator.pop(context, 'login');
              },
            ),
          ),
          body: ListView(
            children: <Widget>[
              Padding(
                padding: EdgeInsets.symmetric(vertical: 10),
                child: Carousel(
                    widgetList: Provider.of<AppData>(context)
                        .createImageTileList(plantID: plantID)),
              ),
              Padding(
                padding: EdgeInsets.symmetric(
                    horizontal: MediaQuery.of(context).size.width * 0.03),
                child: Consumer<AppData>(builder: (context, library, child) {
                  return Provider.of<AppData>(context)
                      .displayInfoCards(plantID: plantID);
                }),
              ),
              SizedBox(
                height: 10,
              ),
              SizedBox(
                child: FlatButton(
                  padding: EdgeInsets.all(10.0),
                  child: Icon(
                    Icons.delete_forever,
                    size: 30,
                    color: kGreenDark,
                  ),
                  onPressed: () {
                    showDialog(
                      context: context,
                      builder: (BuildContext context) {
                        return DialogConfirm(
                            title: '! Confirm Plant Removal',
                            text:
                                'Are you sure you would like to delete this plant and all related information?  This cannot be undone.',
                            onPressed: () {
                              Navigator.pop(context);
                              Provider.of<AppData>(context)
                                  .plantRemoveReferenceDelete(plantID: plantID);
                            });
                      },
                    );
                  },
                ),
              ),
              SizedBox(height: 5),
              Text(
                plantID,
                textAlign: TextAlign.center,
                style: TextStyle(color: kGreenMedium),
              ),
              SizedBox(height: 5),
            ],
          ),
        ),
      ),
    );
  }
}
