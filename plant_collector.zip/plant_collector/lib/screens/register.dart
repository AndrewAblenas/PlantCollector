import 'package:flutter/material.dart';
import 'package:plant_collector/formats/constants.dart';
import 'package:plant_collector/models/network.dart';
import 'package:plant_collector/widgets/buttons/button_add.dart';
import 'package:plant_collector/models/app_data.dart';
import 'package:provider/provider.dart';
import 'package:plant_collector/widgets/inputs/input_card.dart';

class RegisterScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return ListenableProvider(
      builder: (context) => AppData(),
      child: SafeArea(
        child: Scaffold(
          backgroundColor: kGreenLight,
          body: ListView(
            children: <Widget>[
              Icon(
                Icons.ac_unit,
                size: 120,
              ),
              SizedBox(height: 10.0),
              Text(
                'Plant Collector',
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontSize: 40,
                  color: Colors.white,
                ),
              ),
              SizedBox(height: 20.0),
              InputCard(
                cardPrompt: 'Enter your email address',
                onChanged: (input) {
                  UserAuthentication().email = input;
                },
                validator: (input) {
                  String response;
                  if (UserAuthentication().email.contains('@')) {
                    response = 'Please double check your email';
                  }
                  return response;
                },
              ),
              SizedBox(height: 20.0),
              InputCard(
                cardPrompt: 'Create a secure password',
                onChanged: (input) {
                  UserAuthentication().password = input;
                },
                validator: (input) {
                  String response;
                  if (UserAuthentication().password.length <= 7) {
                    response = 'Your password must be atleast 8 characters';
                  }
                  return response;
                },
              ),
              SizedBox(height: 20.0),
              ButtonAdd(
                buttonText: 'SUBMIT',
                onPress: () {
                  //TODO registration of users works, but login fails for some reason
                  UserAuthentication().userRegister();
                },
              ),
            ],
          ),
        ),
      ),
    );
  }
}
