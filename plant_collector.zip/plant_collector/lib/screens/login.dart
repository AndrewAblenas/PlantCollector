import 'package:flutter/material.dart';
import 'package:plant_collector/formats/constants.dart';
import 'package:plant_collector/widgets/buttons/button_add.dart';
import 'package:plant_collector/models/app_data.dart';
import 'package:provider/provider.dart';
import 'package:plant_collector/widgets/inputs/input_card.dart';
import 'package:plant_collector/models/network.dart';

class LoginScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        backgroundColor: kGreenLight,
        body: ListView(
          children: <Widget>[
            SizedBox(height: 20.0),
            Icon(
              Icons.ac_unit,
              size: 120,
            ),
            SizedBox(height: 10.0),
            Text(
              'Plant Collector',
              textAlign: TextAlign.center,
              style: TextStyle(
                fontSize: 40,
                color: Colors.white,
              ),
            ),
            SizedBox(height: 20.0),
            InputCard(
              cardPrompt: 'Enter your email address',
              onChanged: (input) {
                Provider.of<UserAuthentication>(context).email = input;
                print(Provider.of<UserAuthentication>(context).email);
              },
              validator: (input) {
                String response;
                if (Provider.of<UserAuthentication>(context)
                    .email
                    .contains('@')) {
                  response = 'Please double check your email';
                }
                return response;
              },
            ),
            InputCard(
              cardPrompt: 'Enter your password',
              onChanged: (input) {
                Provider.of<UserAuthentication>(context).password = input;
              },
              validator: (input) {
                String response;
                if (Provider.of<UserAuthentication>(context).password.length <=
                    7) {
                  response = 'Your password must be atleast 8 characters';
                }
                return response;
              },
            ),
            ButtonAdd(
              buttonText: 'SIGN INTO ACCOUNT',
              onPress: () {
                //TODO: Figure out why logging a user in crashes the app!
                Provider.of<UserAuthentication>(context).loginUser();
                //if login successful, carry out these:
                Provider.of<AppData>(context).loadingStatus = true;
                Provider.of<AppData>(context).initLibraryState();
                Provider.of<AppData>(context).loadingStatus = false;
                Navigator.pushNamed(context, 'library');
              },
            ),
            FlatButton(
              child: Text(
                'Register a new account',
                style: TextStyle(
                  color: kGreenMedium,
                  fontSize: 16.0,
                ),
              ),
              onPressed: () {
                Navigator.pushNamed(context, 'register');
              },
            )
          ],
        ),
      ),
    );
  }
}
