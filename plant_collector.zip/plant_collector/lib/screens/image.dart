import 'package:flutter/material.dart';
import 'dart:io';
import 'package:photo_view/photo_view.dart';

class ImageScreen extends StatelessWidget {
  final File image;
  ImageScreen({this.image});
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: Container(
        child: PhotoView(
          imageProvider: FileImage(image),
          maxScale: 4.0,
        ),
      ),
    );
  }
}

//            Row(
//              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
//              children: <Widget>[
//                RaisedButton(
//                  color: kGreenDark,
//                  onPressed: () {
//                    //TODO use as plant avatar
//                    Navigator.pop(context);
//                  },
//                  child: Icon(
//                    Icons.grid_on,
//                    size: 50,
//                    color: Colors.black,
//                  ),
//                ),
//                RaisedButton(
//                  color: kGreenDark,
//                  onPressed: () {
//                    //TODO delete this image
//                    Navigator.pop(context);
//                  },
//                  child: Icon(
//                    Icons.delete_forever,
//                    size: 50,
//                  ),
//                ),
//              ],
//            ),
