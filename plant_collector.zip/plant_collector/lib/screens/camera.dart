import 'package:flutter/material.dart';
import 'package:plant_collector/formats/constants.dart';
import 'package:plant_collector/models/app_data.dart';
import 'package:provider/provider.dart';

class CameraScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: kGreenLight,
      body: Container(
        height: MediaQuery.of(context).size.height,
        child: Consumer<AppData>(builder: (context, library, child) {
          return Column(
              mainAxisAlignment: MainAxisAlignment.end,
              mainAxisSize: MainAxisSize.max,
              children: <Widget>[
                Expanded(
                  child: Center(
                    child: Provider.of<AppData>(context).cameraCapture == null
                        ? Text('No image to display yet.')
                        : Image.file(
                            Provider.of<AppData>(context).cameraCapture),
                  ),
                ),
                RaisedButton(
                  color: kGreenDark,
                  onPressed: () {
                    if (Provider.of<AppData>(context).cameraCapture == null) {
                      Provider.of<AppData>(context).getImage();
                    } else {
                      Provider.of<AppData>(context).confirmImage();
                      Provider.of<AppData>(context).imagesGenerateFileList(
                          plantID:
                              Provider.of<AppData>(context).forwardingPlantID);
                      Navigator.pop(context);
                    }
                  },
                  child: Provider.of<AppData>(context).cameraCapture == null
                      ? Icon(
                          Icons.add_a_photo,
                          size: 50,
                        )
                      : Icon(
                          Icons.check_box,
                          size: 50,
                        ),
                ),
              ]);
        }),
      ),
    );
  }
}
