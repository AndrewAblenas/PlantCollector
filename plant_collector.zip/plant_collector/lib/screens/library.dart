import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:modal_progress_hud/modal_progress_hud.dart';
import 'package:plant_collector/formats/constants.dart';
import 'package:plant_collector/models/app_data.dart';
import 'package:plant_collector/widgets/cards/card_stat.dart';
import 'package:plant_collector/widgets/buttons/button_add.dart';
import 'package:provider/provider.dart';
import 'package:plant_collector/widgets/dialogs/dialog_input.dart';
import 'package:plant_collector/models/network.dart';

class LibraryScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        backgroundColor: kGreenLight,
        appBar: AppBar(
          backgroundColor: kGreenDark,
          centerTitle: true,
          elevation: 20.0,
          title: Text(
            'COLLECTION LIBRARY',
            style: TextStyle(
              color: Colors.white,
              fontSize: 25.0,
              fontWeight: FontWeight.w300,
            ),
          ),
          leading: FlatButton(
            child: Icon(
              Icons.list,
              color: Colors.white,
              size: 40.0,
            ),
            onPressed: () {
              UserAuthentication().signOutUser();
              Navigator.pushNamed(context, 'login');
            },
          ),
        ),
        body: ModalProgressHUD(
          opacity: 0.5,
          color: kGreenDark,
          progressIndicator: CircularProgressIndicator(),
          inAsyncCall: Provider.of<AppData>(context).loadingStatus,
          child: Padding(
            padding: EdgeInsets.only(
              top: 0.0,
              left: 10.0,
              right: 10.0,
              bottom: 0.0,
            ),
            child: ListView(
              children: <Widget>[
                SizedBox(height: 20.0),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: <Widget>[
                    CardStat(
                      cardLabel: 'Plant',
                      cardValue:
                          Provider.of<AppData>(context).plantCountLocal(),
                    ),
                    CardStat(
                      cardLabel: 'Collection',
                      cardValue:
                          Provider.of<AppData>(context).collectionCountLocal(),
                    ),
                    CardStat(
                      cardLabel: 'Photo',
                      cardValue: Provider.of<AppData>(context).imageCount(),
                    ),
                  ],
                ),
                SizedBox(height: 10.0),
                SizedBox(height: 10.0),
                Consumer<AppData>(builder: (context, library, child) {
                  return Provider.of<AppData>(context).displayCollections();
                }),
                ButtonAdd(
                  buttonText: 'Create Collection',
                  dialog: DialogInput(
                      title: 'Create Collection',
                      text: 'Please provide a new Collection name.',
                      onPressed: () {
                        Provider.of<AppData>(context).collectionNew();
                        Provider.of<AppData>(context).displayCollections();
                      }),
                ),
                SizedBox(height: 20.0),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
