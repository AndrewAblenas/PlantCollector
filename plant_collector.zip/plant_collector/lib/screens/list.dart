import 'package:flutter/material.dart';

class ListScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        body: Column(
            //TODO show list of all plants as buttons when click go to plant page
            ),
      ),
    );
  }
}
