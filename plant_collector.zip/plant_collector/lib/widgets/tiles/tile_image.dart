import 'package:flutter/material.dart';
import 'dart:io';
import 'package:plant_collector/formats/constants.dart';
import 'package:plant_collector/widgets/dialogs/dialog_confirm.dart';
import 'package:provider/provider.dart';
import 'package:plant_collector/models/app_data.dart';
import 'package:plant_collector/screens/image.dart';

class TileImage extends StatelessWidget {
  final File image;
  final String imageDate;
  TileImage({@required this.image, @required this.imageDate});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.all(4.0),
      child: GestureDetector(
        onLongPress: () {
          showDialog(
            context: context,
            builder: (BuildContext context) {
              return DialogConfirm(
                title: 'Delete Image',
                text: 'Are you sure you want to delete this image?',
                onPressed: () {
                  Provider.of<AppData>(context)
                      .deleteImageRemoveReference(image: image);
                  Provider.of<AppData>(context).imagesGenerateFileList(
                      plantID: Provider.of<AppData>(context).forwardingPlantID);
                },
              );
            },
          );
        },
        child: Container(
          margin: EdgeInsets.only(bottom: 10.0),
          width: MediaQuery.of(context).size.width * 0.94,
          decoration: BoxDecoration(
            image: DecorationImage(
              image: FileImage(image),
              fit: BoxFit.cover,
              alignment: Alignment.center,
            ),
            boxShadow: kShadowBox,
          ),
          child: FlatButton(
            onPressed: () {
              Navigator.push(
                  context,
                  MaterialPageRoute(
                      builder: (context) => ImageScreen(
                            image: image,
                          )));
            },
            child: Column(
              mainAxisAlignment: MainAxisAlignment.end,
              children: <Widget>[
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  mainAxisSize: MainAxisSize.max,
                  children: <Widget>[
                    SizedBox(
                      width: 30,
                    ),
                    Padding(
                      padding: EdgeInsets.all(5.0),
                      child: Container(
                        color: Color(0x33000000),
                        padding: EdgeInsets.all(3),
                        child: Text(
                          imageDate,
                          textAlign: TextAlign.center,
                          style: TextStyle(
                            fontSize: 18.0,
                            color: Colors.white,
                          ),
                        ),
                      ),
                    ),
                    Container(
                      width: 35,
                      child: FlatButton(
                          onPressed: () {
                            showDialog(
                              context: context,
                              builder: (BuildContext context) {
                                return DialogConfirm(
                                  title: 'Plant Thumbnail',
                                  text:
                                      'Would you like to use this image as the plant thumbail image?',
                                  onPressed: () {
                                    Provider.of<AppData>(context)
                                        .imageCreateThumbnail(image: image);
                                  },
                                );
                              },
                            );
                          },
                          child: Icon(Icons.grid_on,
                              color: Color(0x55FFFFFF), size: 21.0)),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
