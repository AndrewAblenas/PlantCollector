import 'package:flutter/material.dart';
import 'package:plant_collector/formats/constants.dart';
import 'package:plant_collector/screens/plant.dart';
import 'package:plant_collector/widgets/dialogs/dialog_select.dart';
import 'package:provider/provider.dart';
import 'package:plant_collector/models/app_data.dart';

class TilePlant extends StatelessWidget {
  final String tileLabel;
  final String tilePlantID;
  final String collectionID;
  TilePlant({
    @required this.tileLabel,
    @required this.tilePlantID,
    @required this.collectionID,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onLongPress: () {
        showDialog(
          context: context,
          builder: (BuildContext context) {
            return DialogSelect(
              title: 'Move to Another Collection',
              text:
                  'Please select the collection where you would like to move this plant.',
              plantID: tilePlantID,
              collectionID: collectionID,
              listBuildColumn: Provider.of<AppData>(context)
                  .createCollectionListButtons(
                      plantID: tilePlantID, oldCollectionID: collectionID),
            );
          },
        );
      },
      child: Container(
        decoration: BoxDecoration(
          boxShadow: kShadowBox,
          image: DecorationImage(
            image: Provider.of<AppData>(context)
                        .imageGetThumbnail(plantID: tilePlantID) ==
                    null
                ? AssetImage('assets/images/default.png')
                //note currently using provider instead of forwarding data
                : FileImage(
                    Provider.of<AppData>(context)
                        .imageGetThumbnail(plantID: tilePlantID),
                  ),
            fit: BoxFit.cover,
            alignment: Alignment.center,
          ),
        ),
        child: FlatButton(
          onPressed: () {
            //save the parent collection ID for use in the plant screen (delete plant function)
            Provider.of<AppData>(context).forwardingCollection = collectionID;
            Provider.of<AppData>(context).forwardingPlantID = tilePlantID;
            Provider.of<AppData>(context).imageFileList = null;
            Provider.of<AppData>(context).loadingStatus = false;
            Provider.of<AppData>(context)
                .imagesGenerateFileList(plantID: tilePlantID);
            Navigator.push(
                context,
                MaterialPageRoute(
                    builder: (context) => PlantScreen(plantID: tilePlantID)));
          },
          child: Column(
            mainAxisAlignment: MainAxisAlignment.end,
            children: <Widget>[
              Padding(
                padding: EdgeInsets.all(1.0),
                child: Container(
                  color: Color(0x33000000),
                  padding: EdgeInsets.all(3),
                  child: Text(
                    tileLabel,
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      fontSize: 10.0,
                      color: Colors.white,
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
