import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:plant_collector/models/app_data.dart';

class PlantGrid extends StatelessWidget {
  final List<Widget> tileList;
  PlantGrid(this.tileList);
  @override
  Widget build(BuildContext context) {
    return Container(
      child: Consumer<AppData>(builder: (context, library, child) {
        return GridView.count(
          crossAxisCount: 3,
          mainAxisSpacing: 5.0,
          crossAxisSpacing: 5.0,
          shrinkWrap: true,
          primary: false,
          padding: EdgeInsets.only(bottom: 10.0),
          children: tileList,
        );
      }),
    );
  }
}
