import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:plant_collector/models/app_data.dart';
import 'package:carousel_slider/carousel_slider.dart';

class Carousel extends StatelessWidget {
  final List<Widget> widgetList;
  Carousel({@required this.widgetList});
  @override
  Widget build(BuildContext context) {
    return Container(
      child: Consumer<AppData>(builder: (context, library, child) {
        return CarouselSlider(
          items: widgetList,
          initialPage: 0,
          height: MediaQuery.of(context).size.width * 0.96,
          viewportFraction: 0.94,
          enableInfiniteScroll: false,
        );
      }),
    );
  }
}
