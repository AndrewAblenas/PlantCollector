import 'package:flutter/material.dart';
import 'package:plant_collector/formats/constants.dart';
import 'package:plant_collector/widgets/dialogs/dialog_confirm.dart';
import 'package:provider/provider.dart';
import 'package:plant_collector/models/app_data.dart';

class ButtonDelete extends StatelessWidget {
  final String collectionID;
  ButtonDelete({@required this.collectionID});

  @override
  Widget build(BuildContext context) {
    return Container(
      child: RaisedButton(
        color: kGreenLight,
        hoverColor: kGreenMedium,
        elevation: 5.0,
        hoverElevation: 10.0,
        padding: EdgeInsets.all(10.0),
        child: CircleAvatar(
          foregroundColor: kGreenDark,
          backgroundColor: Colors.white,
          child: Icon(
            Icons.delete_forever,
            size: 35.0,
          ),
        ),
        onPressed: () {
          showDialog(
            context: context,
            builder: (BuildContext context) {
              return DialogConfirm(
                title: 'Delete Collection',
                text: 'Are you sure you want to delete this collection?',
                onPressed: () {
                  //TODO Every second consecutive collection delete doesn't refresh?
                  Provider.of<AppData>(context)
                      .collectionDelete(collectionID: collectionID);
                },
              );
            },
          );
        },
      ),
    );
  }
}
