import 'package:flutter/material.dart';
import 'package:plant_collector/formats/constants.dart';
import 'package:provider/provider.dart';
import 'package:plant_collector/models/app_data.dart';

class ButtonAddImage extends StatelessWidget {
  final String plantID;
  ButtonAddImage({@required this.plantID});

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: EdgeInsets.only(bottom: 10.0),
      padding: EdgeInsets.all(4.0),
      width: MediaQuery.of(context).size.width * 0.94,
      decoration: BoxDecoration(
        boxShadow: [
          BoxShadow(
            color: kShadowColor,
            blurRadius: 8.0,
            offset: Offset(0.0, 5.0),
            spreadRadius: -5.0,
          ),
        ],
      ),
      child: RaisedButton(
        color: kGreenMedium,
        elevation: 0,
        hoverElevation: 0,
        padding: EdgeInsets.all(10.0),
        child: CircleAvatar(
          foregroundColor: kGreenMedium,
          backgroundColor: Colors.white,
          radius: 70,
          child: Icon(
            Icons.camera_alt,
            size: 100.0,
          ),
        ),
        onPressed: () {
          Provider.of<AppData>(context).forwardingPlantID = plantID;
          Provider.of<AppData>(context).cameraCapture = null;
          Provider.of<AppData>(context).imageAddButtonAction();
//          Navigator.push(
//            context,
//            MaterialPageRoute(
//              builder: (context) => CameraScreen(),
//            ),
//          );
//          showDialog(
//            context: context,
//            builder: (BuildContext context) {
//              return DialogInput(
//                title: 'Add Image',
//                text:
//                    'This will eventually be replaced by an image selector/camera.',
//                onPressed: () {},
//              );
//            },
//          );
        },
      ),
    );
  }
}
