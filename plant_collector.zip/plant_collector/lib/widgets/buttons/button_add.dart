import 'package:flutter/material.dart';
import 'package:plant_collector/formats/constants.dart';

class ButtonAdd extends StatelessWidget {
  final String buttonText;
  final Function onPress;
  final Widget dialog;
  ButtonAdd({this.buttonText, this.onPress, this.dialog});

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: EdgeInsets.all(5.0),
      child: RaisedButton(
          textColor: Colors.white,
          color: kGreenDark,
          hoverColor: kGreenMedium,
          elevation: 5.0,
          hoverElevation: 10.0,
          padding: EdgeInsets.all(10.0),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: <Widget>[
              CircleAvatar(
                foregroundColor: kGreenDark,
                backgroundColor: Colors.white,
                child: Icon(
                  Icons.add,
                  size: 40.0,
                ),
              ),
              Text(
                '  $buttonText',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 30.0,
                  fontWeight: FontWeight.w300,
                ),
              ),
            ],
          ),
          onPressed: () {
            if (onPress != null) {
              onPress();
            }
            if (dialog != null) {
              showDialog(
                context: context,
                builder: (BuildContext context) {
                  return dialog;
                },
              );
            }
          }),
    );
  }
}
