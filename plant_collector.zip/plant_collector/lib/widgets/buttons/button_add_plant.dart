import 'package:flutter/material.dart';
import 'package:plant_collector/formats/constants.dart';
import 'package:plant_collector/widgets/dialogs/dialog_input.dart';
import 'package:provider/provider.dart';
import 'package:plant_collector/models/app_data.dart';

class ButtonAddPlant extends StatelessWidget {
  final String collectionID;
  ButtonAddPlant({@required this.collectionID});

  @override
  Widget build(BuildContext context) {
    return Container(
      child: RaisedButton(
        color: kGreenLight,
        hoverColor: kGreenMedium,
        elevation: 5.0,
        hoverElevation: 10.0,
        padding: EdgeInsets.all(10.0),
        child: CircleAvatar(
          foregroundColor: kGreenDark,
          backgroundColor: Colors.white,
          child: Icon(
            Icons.add,
            size: 40.0,
          ),
        ),
        onPressed: () {
          showDialog(
            context: context,
            builder: (BuildContext context) {
              return DialogInput(
                title: 'Create Plant',
                text: 'Please provide the name of your new plant',
                onPressed: () {
                  Provider.of<AppData>(context)
                      .plantNew(collectionID: collectionID);
                },
              );
            },
          );
        },
      ),
    );
  }
}
