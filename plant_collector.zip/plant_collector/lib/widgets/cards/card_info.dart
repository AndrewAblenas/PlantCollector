import 'package:flutter/material.dart';
import 'package:plant_collector/formats/constants.dart';
import 'package:plant_collector/models/app_data.dart';
import 'package:plant_collector/widgets/dialogs/dialog_confirm.dart';
import 'package:provider/provider.dart';
import 'package:plant_collector/widgets/dialogs/dialog_input.dart';

class CardInfo extends StatelessWidget {
  final String plantID;
  final String cardKey;
  final String displayLabel;
  final String displayText;
  CardInfo(
      {@required this.plantID,
      @required this.cardKey,
      @required this.displayLabel,
      @required this.displayText});
  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onLongPress: () {
        showDialog(
          context: context,
          builder: (BuildContext context) {
            return DialogConfirm(
              title: 'Remove Information',
              text:
                  'Are you sure you would like to remove this information and hide the tile?',
              onPressed: () async {
                Provider.of<AppData>(context).newDataInput = '';
                await Provider.of<AppData>(context)
                    .plantUpdateValue(plantID: plantID, plantKey: cardKey);
                Provider.of<AppData>(context).newDataInput = null;
              },
            );
          },
        );
      },
      child: Container(
        padding: EdgeInsets.symmetric(horizontal: 5.0, vertical: 3.0),
        margin: EdgeInsets.symmetric(horizontal: 5.0, vertical: 3.0),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(3.0),
          boxShadow: kShadowBox,
          color: kGreenDark,
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: <Widget>[
            Padding(
              padding: EdgeInsets.only(top: 16.0),
              child: Text(
                '$displayText',
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontSize: 28.0,
                  color: Colors.white,
                  shadows: kShadowText,
                ),
              ),
            ),
            FlatButton(
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: <Widget>[
                  CircleAvatar(
                    backgroundColor: kGreenMedium,
                    foregroundColor: kGreenDark,
                    radius: 8.0,
                    child: Icon(
                      Icons.edit,
                      size: 12.0,
                    ),
                  ),
                  SizedBox(
                    width: 5.0,
                  ),
                  Text(
                    '$displayLabel',
                    textAlign: TextAlign.start,
                    style: TextStyle(
                      fontSize: 16.0,
                      color: kGreenMedium,
                    ),
                  ),
                ],
              ),
              onPressed: () {
                showDialog(
                  context: context,
                  barrierDismissible: false,
                  builder: (BuildContext context) {
                    return DialogInput(
                      title: displayLabel,
                      text: '$displayText\n\n Please provide and update below.',
                      hintText: displayText,
                      onPressed: () {
                        Provider.of<AppData>(context).plantUpdateValue(
                            plantID: plantID, plantKey: cardKey);
                      },
                    );
                  },
                );
              },
            ),
          ],
        ),
      ),
    );
  }
}
