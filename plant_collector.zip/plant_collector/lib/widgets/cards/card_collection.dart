import 'package:flutter/material.dart';
import 'package:plant_collector/formats/constants.dart';
import 'package:plant_collector/widgets/dialogs/dialog_input.dart';
import 'package:provider/provider.dart';
import 'package:plant_collector/models/app_data.dart';

class CardCollection extends StatelessWidget {
  final String collectionName;
  final String collectionID;
  final String collectionPlantTotal;
  final Widget collectionChild;

  CardCollection(
      {@required this.collectionName,
      @required this.collectionID,
      @required this.collectionPlantTotal,
      this.collectionChild});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.all(5.0),
      margin: EdgeInsets.symmetric(
        horizontal: 5.0,
        vertical: 16.0,
      ),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(5.0),
        boxShadow: kShadowBox,
        color: Colors.white,
      ),
      child: Padding(
        padding: EdgeInsets.only(
          bottom: 16.0,
        ),
        child: Column(
          children: <Widget>[
            Padding(
              padding: EdgeInsets.all(14.0),
              child: GestureDetector(
                onLongPress: () {
                  showDialog(
                    context: context,
                    builder: (BuildContext context) {
                      return DialogInput(
                        title: 'Rename Collection',
                        text: 'Please enter a new name.',
                        onPressed: () {
                          Provider.of<AppData>(context)
                              .collectionRename(collectionID: collectionID);
                        },
                        hintText: collectionName,
                      );
                    },
                  );
                },
                child: Text(
                  collectionName.toUpperCase(),
                  style: TextStyle(
                    fontSize: 25.0,
                    fontWeight: FontWeight.w300,
                  ),
                ),
              ),
            ),
            SizedBox(
              height: 1.0,
              width: 200.0,
              child: Container(
                color: kGreenDark,
              ),
            ),
            SizedBox(height: 20.0),
            Consumer<AppData>(builder: (context, library, child) {
              return collectionChild;
            }),
            SizedBox(height: 20.0),
            Text(
              collectionPlantTotal == '1'
                  ? '$collectionPlantTotal plant in collection'
                  : '$collectionPlantTotal plants in collection',
              style: TextStyle(color: Color(0x44000000)),
            )
          ],
        ),
      ),
    );
  }
}
