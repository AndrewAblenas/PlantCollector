import 'package:flutter/material.dart';
import 'package:plant_collector/formats/constants.dart';

class CardStat extends StatelessWidget {
  final String cardLabel;
  final String cardValue;
  CardStat({this.cardLabel, this.cardValue});

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: EdgeInsets.all(5.0),
      padding: EdgeInsets.symmetric(horizontal: 20.0, vertical: 15.0),
      constraints: BoxConstraints(maxWidth: double.infinity),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(5.0),
        boxShadow: kShadowBox,
        color: kGreenDark,
      ),
      child: Column(
        children: <Widget>[
          Text(
            cardValue != null ? cardValue.toString() : '0',
            style: TextStyle(
              fontSize: 60.0,
              color: Colors.white,
              shadows: kShadowText,
            ),
          ),
          SizedBox(
            height: 1.0,
            width: 60.0,
            child: Container(
              color: kGreenMedium,
            ),
          ),
          SizedBox(height: 10.0),
          Text(
            cardValue == '1' ? '$cardLabel' : '${cardLabel}s',
            style: TextStyle(
              color: Colors.white,
            ),
          ),
        ],
      ),
    );
  }
}
