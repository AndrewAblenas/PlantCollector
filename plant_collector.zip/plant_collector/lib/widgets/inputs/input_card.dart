import 'package:flutter/material.dart';
import 'package:plant_collector/formats/constants.dart';
import 'package:provider/provider.dart';
import 'package:plant_collector/models/app_data.dart';

class InputCard extends StatelessWidget {
  final String cardPrompt;
  final Function onChanged;
  final Function validator;
  InputCard({this.cardPrompt, this.onChanged, this.validator});

  @override
  Widget build(BuildContext context) {
    return ListenableProvider(
      builder: (context) => AppData(),
      child: Container(
        padding: EdgeInsets.all(20.0),
        child: Column(
          children: <Widget>[
            Text(
              cardPrompt,
              style: TextStyle(
                color: Colors.black,
                fontSize: 14.0,
              ),
            ),
            TextFormField(
              autofocus: false,
              cursorColor: kGreenDark,
              onChanged: onChanged,
              validator: validator,
            ),
          ],
        ),
      ),
    );
  }
}
