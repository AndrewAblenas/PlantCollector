import 'dart:core';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:plant_collector/formats/constants.dart';
import 'package:plant_collector/models/app_data.dart';
import 'package:provider/provider.dart';

class DialogInput extends StatelessWidget {
  final String title;
  final String text;
  final Function onPressed;
  final String hintText;
  DialogInput({this.title, this.text, this.onPressed, this.hintText});

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      backgroundColor: kGreenLight,
      title: Text(
        title.toUpperCase(),
        textAlign: TextAlign.center,
      ),
      content: Container(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: <Widget>[
            SizedBox(
              height: 1.0,
              width: double.infinity,
              child: Container(
                color: kGreenDark,
              ),
            ),
            SizedBox(
              height: 20.0,
            ),
            Text(
              text,
              textAlign: TextAlign.center,
              style: TextStyle(),
            ),
            TextField(
              decoration: InputDecoration(hintText: hintText),
              autofocus: true,
              textAlign: TextAlign.center,
              minLines: 1,
              maxLines: 10,
              onChanged: (input) {
                Provider.of<AppData>(context).newDataInput = input;
              },
            ),
            SizedBox(height: 20.0),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: <Widget>[
                RaisedButton(
                  color: kGreenDark,
                  textColor: Colors.white,
                  child: Text('Cancel'),
                  onPressed: () {
                    //TODO ensure this doesn't cause any problems
                    Provider.of<AppData>(context).newDataInput = null;
                    Navigator.pop(context);
                  },
                ),
                RaisedButton(
                  color: kGreenDark,
                  textColor: Colors.white,
                  child: Text('Submit'),
                  onPressed: () async {
                    await onPressed();
                    Navigator.pop(context);
                  },
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
