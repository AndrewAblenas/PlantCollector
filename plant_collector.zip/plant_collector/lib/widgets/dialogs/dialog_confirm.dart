import 'package:flutter/material.dart';
import 'package:plant_collector/models/app_data.dart';
import 'package:provider/provider.dart';
import 'package:plant_collector/formats/constants.dart';

class DialogConfirm extends StatelessWidget {
  final String title;
  final String text;
  final Function onPressed;
  DialogConfirm({this.title, this.text, this.onPressed});

  @override
  Widget build(BuildContext context) {
    Provider.of<AppData>(context).loadingStatus = false;
    return AlertDialog(
      backgroundColor: kGreenLight,
      title: Text(
        title.toUpperCase(),
        textAlign: TextAlign.center,
      ),
      content: Container(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: <Widget>[
            SizedBox(
              height: 1.0,
              width: double.infinity,
              child: Container(
                color: kGreenDark,
              ),
            ),
            SizedBox(
              height: 20.0,
            ),
            Text(
              '$text',
              textAlign: TextAlign.center,
            ),
            SizedBox(height: 20.0),
            RaisedButton(
              color: kGreenDark,
              textColor: Colors.white,
              child: Text('Submit'),
              onPressed: () {
                onPressed();
                Navigator.pop(context);
              },
            ),
          ],
        ),
      ),
    );
  }
}
