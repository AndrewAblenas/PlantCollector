import 'package:flutter/material.dart';
import 'package:plant_collector/formats/constants.dart';
import 'package:provider/provider.dart';
import 'package:plant_collector/models/app_data.dart';

//DIALOG WITH A LIST OF BUTTONS TO PROVIDE USER INPUT

class DialogSelect extends StatelessWidget {
  final String title;
  final String text;
  final String plantID;
  final String collectionID;
  final Column listBuildColumn;
  DialogSelect(
      {this.title,
      this.text,
      this.plantID,
      this.collectionID,
      @required this.listBuildColumn});

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      backgroundColor: kGreenLight,
      title: Text(
        title.toUpperCase(),
        textAlign: TextAlign.center,
      ),
      content: Container(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: <Widget>[
            SizedBox(
              height: 1.0,
              width: double.infinity,
              child: Container(
                color: kGreenDark,
              ),
            ),
            SizedBox(
              height: 20.0,
            ),
            Text(
              '$text',
              textAlign: TextAlign.center,
            ),
            SizedBox(height: 20.0),
            listBuildColumn,
            SizedBox(height: 20.0),
            RaisedButton(
              color: kGreenDark,
              textColor: Colors.white,
              child: Text(
                'Cancel',
                style: TextStyle(fontSize: 16.0),
              ),
              onPressed: () {
                Navigator.pop(context);
              },
            ),
          ],
        ),
      ),
    );
  }
}

//SELECTION BUTTON WIDGET

class ButtonDialogSelect extends StatelessWidget {
  final String buttonText;
  final String buttonKey;
  final Function onPress;
  final Widget pushPage;
  ButtonDialogSelect(
      {@required this.buttonText,
      @required this.buttonKey,
      @required this.onPress,
      @required this.pushPage});

  @override
  Widget build(BuildContext context) {
    return RaisedButton(
      color: kGreenDark,
      textColor: Colors.white,
      child: Container(
        width: double.infinity,
        child: Text(
          buttonText,
          style: TextStyle(fontSize: 20.0),
          textAlign: TextAlign.center,
        ),
      ),
      onPressed: () {
        onPress();
        Provider.of<AppData>(context).selectedDialogButtonItem = null;
        Navigator.pop(context);
      },
    );
  }
}
